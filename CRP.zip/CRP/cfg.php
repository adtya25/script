<?php

# Mr.Black86 project
# Thanks for subscribe CRYPTO GRATISAN
# Doge donation : DTHY59Tmbhxq3gKwgPzdLSkjjbkCuUjifZ

// Input login data
$email = "xxxx";
$pass = "xxxx";

// Input cookie data
$useragent = "xxxx";
$tawkuuid = "xxxx";
$cfduid = "xxxx";
$atuvc = "xxxx";
$atuvs = "xxxx";